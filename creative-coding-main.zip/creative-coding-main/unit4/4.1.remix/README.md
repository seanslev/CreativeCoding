# Exercise 4.1. Remix

The ["Remix Exercise"](https://canvas.umw.edu/courses/1499064/assignments/11895976) asks you to remix a digital poem (or poems). Save those remixed HTML files here in this folder, and delete this README file.
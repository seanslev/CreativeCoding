

let rm = RiTa.markov(2);



function preload() {
  result = loadStrings('');
}

function setup(){

	
}

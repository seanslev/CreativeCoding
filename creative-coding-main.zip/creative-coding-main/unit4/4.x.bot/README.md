# Bot

If you choose to complete the [Mastodon bot exercise](https://canvas.umw.edu/courses/1499064/assignments/11895979), add your JSON file to this directory and delete this README file.
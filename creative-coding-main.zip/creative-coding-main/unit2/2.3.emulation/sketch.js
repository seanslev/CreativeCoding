function setup() {
  // create the canvas
  createCanvas(600, 800);

  // disable animation
  noLoop();
}

function draw() {

  background(255);

}
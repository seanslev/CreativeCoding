function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(0);
}
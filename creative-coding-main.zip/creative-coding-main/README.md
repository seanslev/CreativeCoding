# DGST 302: Creative Coding

This repository is intended for students taking the Creative Coding class at the University of Mary Washington. 

Essentially, this is a series of blank canvases on which you can create your projects and exercises.

